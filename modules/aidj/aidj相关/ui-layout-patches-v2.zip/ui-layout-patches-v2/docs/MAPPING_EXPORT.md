# Export 页插槽映射（A~H）
- A：源文件选择（selectedExportFile + 选择/校验按钮 + 提示）
- B：导出选项（命名/冲突策略/scanOnly/forceMp3/ncmdump 等）
- C：导出目标（导出目录/根路径）
- D：操作区（验证/开始/停止 + 阶段提示）
- E：任务状态（task_status/progress/stage）
- F：进度与时间（Progress + 开始/预计/结束）
- G：日志（建议 max-h-[50vh] overflow-auto）
- H：队列（可选）

> 仅移动容器，不改卡片内部任何 className/颜色/逻辑。
