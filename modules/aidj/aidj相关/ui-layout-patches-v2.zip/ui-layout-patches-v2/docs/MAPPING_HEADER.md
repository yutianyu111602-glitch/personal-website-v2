# 顶部状态条（StatusHeader）映射
- left：核心操作键（SYNC、Generate、Undo 等）
- center：摘要（当前 preset、BPM、listeners、dropout）
- right：二级操作（帮助、设置、主题）
注意：仅位置容器；你现有的银色主题不变。
