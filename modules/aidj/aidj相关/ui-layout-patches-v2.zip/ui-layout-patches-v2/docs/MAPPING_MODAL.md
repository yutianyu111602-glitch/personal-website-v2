# Modal 布局映射（ModalShell）
- title：你的标题行
- body：表单/说明
- footer：动作按钮
注意：不改 Modal 背景/阴影/动画，只限制内部宽度与边距。
